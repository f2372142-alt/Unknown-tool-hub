const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, "public");
const MIME = {".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"application/javascript; charset=utf-8",".png":"image/png",".svg":"image/svg+xml",".ico":"image/x-icon"};

function send(res, status, body, type="application/json; charset=utf-8") {
  res.writeHead(status, {"Content-Type":type, "X-Content-Type-Options":"nosniff", "X-Frame-Options":"DENY", "Referrer-Policy":"strict-origin-when-cross-origin"});
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve,reject)=>{
    let data="";
    req.on("data", chunk=>{ data += chunk; if(data.length > 20000){ reject(new Error("অনুরোধটি অনেক বড়")); req.destroy(); }});
    req.on("end",()=>{ try{resolve(JSON.parse(data||"{}"));}catch(e){reject(new Error("সঠিক তথ্য পাঠান"));}});
    req.on("error",reject);
  });
}
const server = http.createServer(async (req,res)=>{
  if(req.method==="POST" && req.url==="/api/generate"){
    if(!process.env.OPENAI_API_KEY) return send(res,503,JSON.stringify({error:"এআই সুবিধা চালু করতে সার্ভারে OPENAI_API_KEY সেট করতে হবে।"}));
    try {
      const body=await readBody(req);
      const type=String(body.type||"").slice(0,40);
      const topic=String(body.topic||"").trim().slice(0,3000);
      if(!topic) return send(res,400,JSON.stringify({error:"আপনার বিষয় বা নির্দেশনা লিখুন।"}));
      const labels = {
        title:"ইউটিউব ভিডিওর আকর্ষণীয় বাংলা শিরোনাম",
        script:"ভিডিওর জন্য স্বাভাবিক, মৌলিক বাংলা স্ক্রিপ্ট",
        caption:"সামাজিক যোগাযোগমাধ্যমের জন্য বাংলা ক্যাপশন",
        hashtags:"বিষয় অনুযায়ী প্রাসঙ্গিক বাংলা ও ইংরেজি হ্যাশট্যাগ",
        thumbnail:"ইউটিউব থাম্বনেইলের জন্য দৃশ্য, লেখা ও রঙের ধারণা",
        ideas:"ভিডিও বা কনটেন্টের জন্য নতুন ও বাস্তবসম্মত ধারণা"
      };
      if(!labels[type]) return send(res,400,JSON.stringify({error:"এই এআই টুলটি পাওয়া যায়নি।"}));
      const prompt = `তুমি UNKNOWN TOOL HUB-এর বাংলা কনটেন্ট সহকারী। সম্পূর্ণ সহজ, স্বাভাবিক বাংলায় উত্তর দাও। ব্যবহারকারীর অনুরোধ: ${labels[type]}। ব্যবহারকারীর বিষয়: ${topic}। অযাচাইকৃত তথ্য বানিয়ে বলবে না। প্রয়োজন হলে সংক্ষিপ্ত শিরোনাম ও তালিকা ব্যবহার করো।`;
      const response=await fetch("https://api.openai.com/v1/responses",{
        method:"POST",
        headers:{"Authorization":"Bearer "+process.env.OPENAI_API_KEY,"Content-Type":"application/json"},
        body:JSON.stringify({model:process.env.OPENAI_MODEL||"gpt-4.1-mini",input:prompt})
      });
      const data=await response.json();
      if(!response.ok) return send(res,502,JSON.stringify({error:"এআই সেবা থেকে উত্তর পাওয়া যায়নি। সার্ভারের API সেটিংস পরীক্ষা করুন।"}));
      let output="";
      if(data.output) for(const item of data.output) if(item.type==="message" && item.content) for(const c of item.content) if(c.type==="output_text") output+=c.text;
      if(!output) output=data.output_text||"দুঃখিত, এবার উত্তর তৈরি করা যায়নি।";
      return send(res,200,JSON.stringify({result:output}));
    } catch(e) {
      return send(res,400,JSON.stringify({error:e.message||"একটি সমস্যা হয়েছে।"}));
    }
  }
  let pathname=decodeURIComponent((req.url||"/").split("?")[0]);
  if(pathname==="/") pathname="/index.html";
  const file=path.normalize(path.join(ROOT,pathname));
  if(!file.startsWith(ROOT)) return send(res,403,"Forbidden","text/plain");
  fs.readFile(file,(err,content)=>{
    if(err) return send(res,404,"Not found","text/plain; charset=utf-8");
    send(res,200,content,MIME[path.extname(file)]||"application/octet-stream");
  });
});
server.listen(PORT,()=>console.log("UNKNOWN TOOL HUB চলছে পোর্ট "+PORT));
