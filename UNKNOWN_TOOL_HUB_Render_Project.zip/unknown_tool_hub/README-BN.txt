UNKNOWN TOOL HUB — চালু করার নির্দেশনা

১) এই ZIP ফাইলটি GitHub-এ একটি নতুন Repository-তে আপলোড করো।
২) Render-এ New > Web Service নির্বাচন করে Repository যুক্ত করো।
৩) Build Command ফাঁকা রাখো।
৪) Start Command দাও: npm start
৫) Render-এর Environment Variables-এ যোগ করো:
   OPENAI_API_KEY = তোমার গোপন OpenAI API key
   OPENAI_MODEL = gpt-4.1-mini
৬) Deploy করো।

গুরুত্বপূর্ণ:
- API key কখনো public HTML বা GitHub-এ লিখবে না।
- AI টুল চালাতে API key এবং API ব্যবহারের জন্য সক্রিয় বিলিং/ক্রেডিট লাগতে পারে।
- API key না দিলে হিসাবের টুলগুলো কাজ করবে, কিন্তু AI কনটেন্ট তৈরি হবে না।
- এটি কোনো Google লগইন ছাড়াই ব্যবহারযোগ্য।
- ওয়েবসাইটের হিসাবগুলো ব্রাউজারেই চলে।
